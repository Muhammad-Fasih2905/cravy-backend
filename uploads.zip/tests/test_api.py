import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app import db as appdb, models, seed
from app.main import app


SHOP = (24.8607, 67.0011)


def at_km(km):
    """A customer location `km` kilometres due north of the shop."""
    return {"latitude": SHOP[0] + km / 111.195, "longitude": SHOP[1]}


@pytest.fixture()
def client(monkeypatch):
    from app.config import settings as cfg
    monkeypatch.setattr(cfg, "shop_latitude", SHOP[0])
    monkeypatch.setattr(cfg, "shop_longitude", SHOP[1])
    eng = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Session = sessionmaker(bind=eng, autoflush=False, expire_on_commit=False)
    monkeypatch.setattr(seed, "engine", eng)
    monkeypatch.setattr(seed, "SessionLocal", Session)
    seed.run()

    def _db():
        d = Session()
        try:
            yield d
        finally:
            d.close()

    app.dependency_overrides[appdb.get_db] = _db
    yield TestClient(app), Session
    app.dependency_overrides.clear()


def ids(Session, slug):
    with Session() as s:
        from sqlalchemy import select
        p = s.scalar(select(models.Product).where(models.Product.slug == slug))
        return p.id, [v.id for v in p.variants], [a.id for a in p.addons]


ORDER = dict(customer_name="Ali Khan", customer_phone="03001234567", city="Karachi",
             address="House 1, Street 2", payment_method="COD", **at_km(2.5))  # 2-3 km band = Rs. 99


def test_menu_preload(client):
    c, _ = client
    r = c.get("/api/menu")
    assert r.status_code == 200 and len(r.json()["categories"]) == 5


def test_quote_uses_server_prices(client):
    c, S = client
    pid, vids, aids = ids(S, "demo-vanilla-scoop")
    item = {"product_id": pid, "variant_id": vids[1], "addon_ids": aids, "quantity": 2}
    r = c.post("/api/cart/quote", json={"items": [item], **at_km(2.5)})
    assert r.status_code == 200
    # (350 + 40 + 30) * 2 = 840 ; + delivery Rs. 99 (2-3 km)
    assert r.json()["subtotal"] == 840 and r.json()["total"] == 939 and r.json()["delivery_band"] == "2-3 km"
    nolocation = c.post("/api/cart/quote", json={"items": [item]}).json()
    assert nolocation["delivery_pending"] is True and nolocation["total"] == 840


def test_coupon_and_invalid_variant(client):
    c, S = client
    pid, vids, _ = ids(S, "demo-cold-drink")
    item = {"product_id": pid, "variant_id": vids[2], "quantity": 1}
    ok = c.post("/api/cart/quote", json={"items": [item], "coupon_code": "demo10", **at_km(2.5)}).json()
    assert ok["discount_total"] == 38 and ok["total"] == 380 - 38 + 99
    assert c.post("/api/cart/quote", json={"items": [{"product_id": pid, "quantity": 1}]}).status_code == 422


def test_order_is_idempotent_and_payment_status(client):
    c, S = client
    pid, vids, _ = ids(S, "demo-cold-drink")
    body = {**ORDER, "items": [{"product_id": pid, "variant_id": vids[1], "quantity": 1}]}
    h = {"Idempotency-Key": "key-12345678"}
    a = c.post("/api/orders", json=body, headers=h)
    b = c.post("/api/orders", json=body, headers=h)
    assert a.status_code == 201 and a.json()["order_number"] == b.json()["order_number"]
    assert a.json()["payment_status"] == "UNPAID"
    assert a.json()["payment_instructions"] is None  # nothing to pay online for COD
    assert a.json()["status"] == "PENDING"
    easy = c.post("/api/orders", json={**body, "payment_method": "EASYPAISA"}, headers={"Idempotency-Key": "key-87654321"})
    assert easy.status_code == 201
    j = easy.json()
    assert j["payment_status"] == "AWAITING_PAYMENT"  # not "pending verification" until the customer sends proof
    assert j["payment_instructions"]["account_number"] == "03143404938"
    assert j["payment_instructions"]["amount"] == j["total"] == 399  # 300 + Rs. 99 delivery
    assert c.post("/api/orders", json={**body, "payment_method": "BANK_TRANSFER"}, headers={"Idempotency-Key": "key-11111111"}).status_code == 422


def test_minimum_order(client):
    c, S = client
    pid, _, _ = ids(S, "demo-cone")
    r = c.post("/api/orders", json={**ORDER, "items": [{"product_id": pid, "quantity": 1}]}, headers={"Idempotency-Key": "key-22222222"})
    assert r.status_code == 422


def test_payment_reference_requires_matching_phone(client):
    c, S = client
    pid, vids, _ = ids(S, "demo-cold-drink")
    body = {**ORDER, "payment_method": "EASYPAISA", "items": [{"product_id": pid, "variant_id": vids[1], "quantity": 1}]}
    n = c.post("/api/orders", json=body, headers={"Idempotency-Key": "key-33333333"}).json()["order_number"]
    bad = c.post(f"/api/orders/{n}/payment-reference", json={"transaction_ref": "TXN12345", "phone": "03009999999"})
    assert bad.status_code == 404
    ok = c.post(f"/api/orders/{n}/payment-reference", json={"transaction_ref": "TXN12345", "phone": ORDER["customer_phone"]})
    assert ok.status_code == 200 and ok.json()["payment_status"] == "PENDING_VERIFICATION"


def test_admin_requires_auth_and_manages_orders(client):
    from app.security import hash_password
    c, S = client
    with S() as s:
        s.add(models.AdminUser(email="a@x.com", password_hash=hash_password("pw-12345")))
        s.commit()
    assert c.get("/api/admin/orders").status_code == 401
    assert c.post("/api/admin/login", json={"email": "a@x.com", "password": "bad"}).status_code == 401
    tok = c.post("/api/admin/login", json={"email": "a@x.com", "password": "pw-12345"}).json()["token"]
    h = {"Authorization": f"Bearer {tok}"}
    pid, vids, _ = ids(S, "demo-cold-drink")
    body = {**ORDER, "payment_method": "EASYPAISA", "items": [{"product_id": pid, "variant_id": vids[1], "quantity": 2}]}
    n = c.post("/api/orders", json=body, headers={"Idempotency-Key": "key-44444444"}).json()["order_number"]
    assert c.patch(f"/api/admin/orders/{n}/payment", json={"status": "PAID"}, headers=h).json()["payment_status"] == "PAID"
    assert c.patch(f"/api/admin/orders/{n}/status", json={"status": "COMPLETED"}, headers=h).json()["status"] == "COMPLETED"
    st = c.get("/api/admin/stats", headers=h).json()
    assert st["total_orders"] == 1 and st["pending_payments"] == 0 and st["total_sales"] == 699  # 600 + Rs. 99 delivery
    assert c.get("/api/admin/orders?method=EASYPAISA", headers=h).json()[0]["order_number"] == n


PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 32
WEBP = b"RIFF" + b"\x00" * 4 + b"WEBP" + b"\x00" * 32


def test_uploads_are_validated_and_receipts_private(client, tmp_path, monkeypatch):
    from app.config import settings as cfg
    from app.security import hash_password
    monkeypatch.setattr(cfg, "upload_dir", str(tmp_path))
    c, S = client
    with S() as s:
        s.add(models.AdminUser(email="a@x.com", password_hash=hash_password("pw-12345"))); s.commit()
    h = {"Authorization": "Bearer " + c.post("/api/admin/login", json={"email": "a@x.com", "password": "pw-12345"}).json()["token"]}
    pid, vids, _ = ids(S, "demo-cold-drink")
    assert c.post(f"/api/admin/products/{pid}/image", files={"file": ("x.png", PNG)}).status_code == 401
    assert c.post(f"/api/admin/products/{pid}/image", files={"file": ("x.png", b"not an image")}, headers=h).status_code == 422
    assert c.post(f"/api/admin/products/{pid}/image", files={"file": ("x.png", PNG)}, headers=h).status_code == 422  # products: WebP only
    ok = c.post(f"/api/admin/products/{pid}/image", files={"file": ("x.webp", WEBP)}, headers=h)
    assert ok.status_code == 200 and ok.json()["image_url"].startswith("/media/products/") and ok.json()["image_url"].endswith(".webp")
    body = {**ORDER, "payment_method": "EASYPAISA", "items": [{"product_id": pid, "variant_id": vids[1], "quantity": 1}]}
    n = c.post("/api/orders", json=body, headers={"Idempotency-Key": "key-55555555"}).json()["order_number"]
    assert c.post(f"/api/orders/{n}/receipt", data={"phone": "03000000000"}, files={"file": ("r.png", PNG)}).status_code == 404
    assert c.post(f"/api/orders/{n}/receipt", data={"phone": ORDER["customer_phone"]}, files={"file": ("r.png", PNG)}).status_code == 200
    assert c.get(f"/api/admin/orders/{n}/receipt").status_code == 401
    assert c.get(f"/api/admin/orders/{n}/receipt", headers=h).status_code == 200


def test_admin_creates_and_deletes_product(client):
    from app.security import hash_password
    c, S = client
    with S() as s:
        s.add(models.AdminUser(email="a@x.com", password_hash=hash_password("pw-12345"))); s.commit()
    h = {"Authorization": "Bearer " + c.post("/api/admin/login", json={"email": "a@x.com", "password": "pw-12345"}).json()["token"]}
    cat = c.get("/api/admin/categories", headers=h).json()[0]["id"]
    pid = c.post("/api/admin/products", json={"name": "Real Shake", "category_id": cat, "base_price": 450}, headers=h).json()["id"]
    assert any(p["name"] == "Real Shake" for cat in c.get("/api/menu").json()["categories"] for p in cat["products"])
    assert c.delete(f"/api/admin/products/{pid}", headers=h).status_code == 200


def _admin_headers(c, S):
    from app.security import hash_password
    with S() as s:
        s.add(models.AdminUser(email="a@x.com", password_hash=hash_password("pw-12345"))); s.commit()
    return {"Authorization": "Bearer " + c.post("/api/admin/login", json={"email": "a@x.com", "password": "pw-12345"}).json()["token"]}


def test_fixed_delivery_rates_by_distance(client):
    c, S = client
    pid, vids, _ = ids(S, "demo-cold-drink")
    line = {"product_id": pid, "variant_id": vids[1], "quantity": 1}  # Rs. 300
    expected = {0.5: 0, 1.5: 79, 2.5: 99, 3.5: 149, 4.5: 199, 5.5: 219, 6.5: 239, 7.5: 249, 8.5: 269, 9.5: 299}
    for km, charge in expected.items():
        q = c.post("/api/cart/quote", json={"items": [line], **at_km(km)}).json()
        assert q["delivery_charge"] == charge and q["total"] == 300 + charge and q["deliverable"] is True, km
    assert c.post("/api/cart/quote", json={"items": [line], **at_km(0.5)}).json()["delivery_band"] == "Up to 1 km"
    far = c.post("/api/cart/quote", json={"items": [line], **at_km(10.5)}).json()
    assert far["deliverable"] is False and "10 km" in far["delivery_message"]
    rates = c.get("/api/delivery-rates").json()
    assert [r["charge"] for r in rates["rates"]] == [0, 79, 99, 149, 199, 219, 239, 249, 269, 299] and rates["max_km"] == 10
    # an order needs a location, and is refused beyond 10 km, wherever it comes from
    key = lambda k: {"Idempotency-Key": k}  # noqa: E731
    base = {**ORDER, "items": [line]}
    no_loc = {k: v for k, v in base.items() if k not in ("latitude", "longitude")}
    assert c.post("/api/orders", json=no_loc, headers=key("key-iiiiiiii")).status_code == 422
    assert c.post("/api/orders", json={**base, **at_km(10.5)}, headers=key("key-jjjjjjjj")).status_code == 422
    ok = c.post("/api/orders", json={**base, **at_km(6.5)}, headers=key("key-kkkkkkkk"))
    assert ok.status_code == 201 and ok.json()["delivery_charge"] == 239 and ok.json()["total"] == 539


def test_fixed_boundaries_and_tax(client):
    from app.delivery import charge_for
    assert [charge_for(k) for k in (0, 1.0, 1.01, 2.0, 2.01, 10.0, 10.01)] == [0, 0, 79, 79, 99, 299, None]
    c, S = client
    h = _admin_headers(c, S)
    assert c.put("/api/admin/settings", json={"tax_percent": 5}, headers=h).json()["tax_percent"] == 5
    pid, vids, _ = ids(S, "demo-cold-drink")
    q = c.post("/api/cart/quote", json={"items": [{"product_id": pid, "variant_id": vids[1], "quantity": 1}], **at_km(1.5)}).json()
    assert q["tax_total"] == 15 and q["delivery_charge"] == 79 and q["total"] == 300 + 15 + 79


def test_shop_location_is_admin_editable_and_required(client, monkeypatch):
    from app.config import settings as cfg
    c, S = client
    h = _admin_headers(c, S)
    pid, vids, _ = ids(S, "demo-cold-drink")
    item = {"items": [{"product_id": pid, "variant_id": vids[1], "quantity": 1}]}
    monkeypatch.setattr(cfg, "shop_latitude", None)
    monkeypatch.setattr(cfg, "shop_longitude", None)
    assert c.post("/api/cart/quote", json={**item, **at_km(2.5)}).status_code == 503  # nowhere to measure from
    assert c.put("/api/admin/settings", json={"shop_latitude": 24.86}, headers=h).status_code == 422  # needs both
    ok = c.put("/api/admin/settings", json={"shop_latitude": SHOP[0], "shop_longitude": SHOP[1]}, headers=h)
    assert ok.status_code == 200 and ok.json()["shop_latitude"] == SHOP[0]
    assert c.post("/api/cart/quote", json={**item, **at_km(2.5)}).json()["delivery_charge"] == 99


def test_admin_edits_sizes_and_toppings(client):
    c, S = client
    h = _admin_headers(c, S)
    pid, vids, aids = ids(S, "demo-vanilla-scoop")
    cur = c.get(f"/api/admin/products/{pid}/options", headers=h).json()
    assert len(cur["variants"]) == 2 and len(cur["addons"]) == 2
    body = {
        "variants": [{"id": cur["variants"][0]["id"], "name": "One scoop", "price": 220}, {"name": "Triple scoop", "price": 480}],
        "addons": [{"id": cur["addons"][0]["id"], "name": "Nutella", "price": 60}],
    }
    new = c.put(f"/api/admin/products/{pid}/options", json=body, headers=h).json()
    assert [v["name"] for v in new["variants"]] == ["One scoop", "Triple scoop"]
    assert new["variants"][0]["id"] == vids[0]  # id kept, so saved carts stay valid
    assert [a["name"] for a in new["addons"]] == ["Nutella"]
    assert c.put(f"/api/admin/products/{pid}/options", json=body).status_code == 401


def _easy_order(c, S, key, phone="03001234567", qty=1):
    pid, vids, _ = ids(S, "demo-cold-drink")
    body = {**ORDER, "customer_phone": phone, "payment_method": "EASYPAISA",
            "items": [{"product_id": pid, "variant_id": vids[1], "quantity": qty}]}
    return c.post("/api/orders", json=body, headers={"Idempotency-Key": key}).json()


def test_payment_methods_endpoint_lists_cod_and_easypaisa(client):
    c, _ = client
    m = {x["method"]: x for x in c.get("/api/payment-methods").json()}
    assert set(m) == {"COD", "EASYPAISA"} and m["COD"]["enabled"] and m["EASYPAISA"]["enabled"]
    assert m["EASYPAISA"]["account_number"] == "03143404938"
    assert c.get("/api/settings").json()["easypaisa_number"] == "03143404938"


def test_easypaisa_full_flow_and_phone_formats(client):
    c, S = client
    h = _admin_headers(c, S)
    o = _easy_order(c, S, "key-aaaaaaaa")
    n = o["order_number"]
    assert c.get(f"/api/orders/{n}").json()["payment_instructions"]["account_number"] == "03143404938"
    # same number written differently is accepted, a different number is not
    ok = c.post(f"/api/orders/{n}/payment-reference", json={"transaction_ref": "tid-123456789", "phone": "+92 300 1234567"})
    assert ok.status_code == 200 and ok.json()["payment_status"] == "PENDING_VERIFICATION"
    assert c.post(f"/api/orders/{n}/payment-reference", json={"transaction_ref": "TID123456789", "phone": "03009999999"}).status_code == 404
    # cannot complete before the money is verified
    assert c.patch(f"/api/admin/orders/{n}/status", json={"status": "COMPLETED"}, headers=h).status_code == 409
    assert c.patch(f"/api/admin/orders/{n}/payment", json={"status": "PAID", "note": "seen in app"}, headers=h).json()["payment_status"] == "PAID"
    assert c.patch(f"/api/admin/orders/{n}/status", json={"status": "COMPLETED"}, headers=h).status_code == 200
    after = c.get(f"/api/orders/{n}").json()
    assert after["payment_status"] == "PAID" and after["payment_instructions"] is None
    assert c.post(f"/api/orders/{n}/payment-reference", json={"transaction_ref": "NEWTID123456", "phone": "03001234567"}).status_code == 422


def test_same_transaction_id_cannot_pay_two_orders(client):
    c, S = client
    a = _easy_order(c, S, "key-bbbbbbbb")["order_number"]
    b = _easy_order(c, S, "key-cccccccc")["order_number"]
    ref = {"transaction_ref": "TXN998877665", "phone": "03001234567"}
    assert c.post(f"/api/orders/{a}/payment-reference", json=ref).status_code == 200
    assert c.post(f"/api/orders/{b}/payment-reference", json={**ref, "transaction_ref": "txn998877665"}).status_code == 409
    assert c.post(f"/api/orders/{a}/payment-reference", json=ref).status_code == 200  # resubmitting on the same order is fine
    assert c.post(f"/api/orders/{b}/payment-reference", json={**ref, "transaction_ref": "ab"}).status_code == 422  # too short


def test_cod_proof_is_refused_and_completion_marks_cash_paid(client):
    c, S = client
    h = _admin_headers(c, S)
    pid, vids, _ = ids(S, "demo-cold-drink")
    body = {**ORDER, "items": [{"product_id": pid, "variant_id": vids[1], "quantity": 1}]}
    n = c.post("/api/orders", json=body, headers={"Idempotency-Key": "key-dddddddd"}).json()["order_number"]
    assert c.post(f"/api/orders/{n}/payment-reference", json={"transaction_ref": "TXN12345678", "phone": ORDER["customer_phone"]}).status_code == 422
    assert c.patch(f"/api/admin/orders/{n}/payment", json={"status": "PENDING_VERIFICATION"}, headers=h).status_code == 422
    done = c.patch(f"/api/admin/orders/{n}/status", json={"status": "COMPLETED"}, headers=h)
    assert done.status_code == 200 and done.json()["status"] == "COMPLETED" and done.json()["payment_status"] == "PAID"
    assert done.json()["completed_at"]
    assert c.get(f"/api/orders/{n}").json()["payment_status"] == "PAID"
    assert c.patch(f"/api/admin/orders/{n}/status", json={"status": "CANCELLED"}, headers=h).status_code == 409  # final
    assert c.patch(f"/api/admin/orders/{n}/status", json={"status": "PREPARING"}, headers=h).status_code == 422  # old steps are gone


def test_cod_order_lifecycle_is_saved_live_and_survives_refresh(client, monkeypatch):
    """New order -> shows in admin as PENDING -> admin completes -> a fresh read says COMPLETED (same as the live event)."""
    from app.routers import admin as admin_router, orders as orders_router
    events = []
    monkeypatch.setattr(orders_router, "publish_order", lambda ev, o: events.append((ev, o.order_number, o.status)))
    monkeypatch.setattr(admin_router, "publish_order", lambda ev, o: events.append((ev, o.order_number, o.status)))
    c, S = client
    h = _admin_headers(c, S)
    pid, vids, _ = ids(S, "demo-cold-drink")
    body = {**ORDER, "items": [{"product_id": pid, "variant_id": vids[1], "quantity": 2}]}
    n = c.post("/api/orders", json=body, headers={"Idempotency-Key": "key-gggggggg"}).json()["order_number"]
    assert events == [("order.created", n, "PENDING")]
    lst = c.get("/api/admin/orders", headers=h)
    assert lst.headers["cache-control"] == "no-store"  # a refresh can never show a cached list
    row = lst.json()[0]
    assert row["order_number"] == n and row["status"] == "PENDING" and row["payment_status"] == "UNPAID"
    assert row["delivery_zone"] == "2-3 km" and row["delivery_charge"] == 99 and row["total"] == 699
    assert row["map_url"].startswith("https://www.google.com/maps?q=") and row["items"][0]["quantity"] == 2
    assert c.get("/api/admin/orders?status=COMPLETED", headers=h).json() == []
    patched = c.patch(f"/api/admin/orders/{n}/status", json={"status": "COMPLETED"}, headers=h).json()
    assert events[-1] == ("order.updated", n, "COMPLETED")
    for _ in range(2):  # "refresh" twice: the server says exactly what the PATCH said
        assert c.get("/api/admin/orders?status=COMPLETED", headers=h).json()[0] == patched
        assert c.get("/api/admin/orders?status=PENDING", headers=h).json() == []
    assert c.get(f"/api/admin/orders/{n}", headers=h).json()["status"] == "COMPLETED"
    st = c.get("/api/admin/stats", headers=h).json()
    assert st["pending_orders"] == 0 and st["completed_orders"] == 1 and st["total_sales"] == 699 and st["pending_amount"] == 0
    assert c.get("/api/admin/orders?updated_since=2999-01-01T00:00:00", headers=h).json() == []
    assert len(c.get("/api/admin/orders?updated_since=2000-01-01T00:00:00", headers=h).json()) == 1


def test_order_slip_is_printable_escaped_and_protected(client):
    c, S = client
    h = _admin_headers(c, S)
    tok = h["Authorization"].removeprefix("Bearer ")
    pid, vids, _ = ids(S, "demo-cold-drink")
    body = {**ORDER, "customer_name": "<script>alert(1)</script>", "items": [{"product_id": pid, "variant_id": vids[1], "quantity": 1}]}
    n = c.post("/api/orders", json=body, headers={"Idempotency-Key": "key-hhhhhhhh"}).json()["order_number"]
    assert c.get(f"/api/admin/orders/{n}/slip").status_code == 401
    r = c.get(f"/api/admin/orders/{n}/slip?token={tok}&autoprint=1")
    assert r.status_code == 200 and "text/html" in r.headers["content-type"]
    assert n in r.text and "COLLECT Rs. 399 IN CASH" in r.text and "2-3 km" in r.text and "window.print()" in r.text
    assert "<script>alert(1)" not in r.text and "&lt;script&gt;" in r.text
    assert "window.print()" not in c.get(f"/api/admin/orders/{n}/slip", headers=h).text


def test_live_stream_requires_admin_and_broker_delivers_across_threads(client):
    import asyncio, threading
    from app.realtime import Broker
    c, _ = client
    assert c.get("/api/admin/orders/stream").status_code == 401
    assert c.get("/api/admin/orders/stream?token=bad.token.value").status_code == 401

    async def run():
        b = Broker()
        q = b.subscribe()
        threading.Thread(target=b.publish, args=("order.created", {"x": 1})).start()
        got = await asyncio.wait_for(q.get(), 2)
        b.unsubscribe(q)
        return got, len(b._subs)
    assert asyncio.run(run()) == (("order.created", {"x": 1}), 0)


def test_cancel_restores_coupon_and_blocks_payment(client):
    c, S = client
    h = _admin_headers(c, S)
    pid, vids, _ = ids(S, "demo-cold-drink")
    body = {**ORDER, "coupon_code": "DEMO10", "payment_method": "EASYPAISA",
            "items": [{"product_id": pid, "variant_id": vids[1], "quantity": 1}]}
    n = c.post("/api/orders", json=body, headers={"Idempotency-Key": "key-eeeeeeee"}).json()["order_number"]
    with S() as s:
        from sqlalchemy import select
        assert s.scalar(select(models.Coupon.used_count).where(models.Coupon.code == "DEMO10")) == 1
    assert c.patch(f"/api/admin/orders/{n}/status", json={"status": "CANCELLED"}, headers=h).status_code == 200
    with S() as s:
        assert s.scalar(select(models.Coupon.used_count).where(models.Coupon.code == "DEMO10")) == 0
    assert c.post(f"/api/orders/{n}/payment-reference", json={"transaction_ref": "TXN12345678", "phone": ORDER["customer_phone"]}).status_code == 422
    assert c.patch(f"/api/admin/orders/{n}/payment", json={"status": "PAID"}, headers=h).status_code == 409


def test_admin_settings_guard_payment_methods(client):
    c, S = client
    h = _admin_headers(c, S)
    assert c.put("/api/admin/settings", json={"easypaisa_number": "12345"}, headers=h).status_code == 422
    assert c.put("/api/admin/settings", json={"easypaisa_number": "0314 3404938"}, headers=h).json()["easypaisa_number"] == "03143404938"
    assert c.put("/api/admin/settings", json={"cod_enabled": False, "easypaisa_enabled": False}, headers=h).status_code == 422
    assert c.put("/api/admin/settings", json={"cod_enabled": False}, headers=h).status_code == 200
    pid, vids, _ = ids(S, "demo-cold-drink")
    body = {**ORDER, "items": [{"product_id": pid, "variant_id": vids[1], "quantity": 1}]}
    assert c.post("/api/orders", json=body, headers={"Idempotency-Key": "key-ffffffff"}).status_code == 422  # COD switched off


def _menu(c):
    return {p["slug"]: p for cat in c.get("/api/menu").json()["categories"] for p in cat["products"]}


def test_real_menu_import_prices_categories_and_cleanup(client):
    from app import menu_seed
    from app.menu_data import CATEGORIES, PRODUCTS
    c, S = client
    assert "demo-cold-drink" in _menu(c)  # the starter menu is there before the import
    with S() as s:
        first = menu_seed.import_menu(s)
    assert first["products_added"] == len(PRODUCTS) == 52 and first["demo_removed"] >= 1
    cats = c.get("/api/menu").json()["categories"]
    assert [x["slug"] for x in cats] == [slug for slug, _ in CATEGORIES]
    assert [x["name"] for x in cats][:3] == ["Ice Cream", "Margaritas", "Mocktails"]
    menu = _menu(c)
    assert len(menu) == len(PRODUCTS) == 52 and not any(p["is_demo"] for p in menu.values())
    # price = product price + size surcharge (the formula in the supplied data)
    assert [(v["name"], v["price"]) for v in menu["mango"]["variants"]] == [("SINGLE", 139), ("DOUBLE", 219)]
    assert [(v["name"], v["price"]) for v in menu["apple-mint-margarita"]["variants"]] == [("REGULAR", 249), ("LARGE", 349)]
    assert [(v["name"], v["price"]) for v in menu["blue-lagoon"]["variants"]] == [("REGULAR", 349), ("LARGE", 449)]
    assert [(v["name"], v["price"]) for v in menu["carrot-juice"]["variants"]] == [("REGULAR", 299), ("LARGE", 399)]
    for slug, price, big in (("pina-colada", 279, 349), ("lemon", 149, 199), ("cold-coffee", 349, 449), ("banana-shake-milk-shakes", 249, 299)):
        assert menu[slug]["base_price"] == price and [v["price"] for v in menu[slug]["variants"]] == [price, big]
    assert {s for s, p in menu.items() if p["is_featured"]} == {"apple-mint-margarita", "lemon-margarita", "mint-margarita"}
    assert all(p["image_url"] and p["images"] == [p["image_url"]] and p["is_available"] and p["discount_percent"] == 0 for p in menu.values())  # the photo addresses listed in the menu file
    # both "Banana Shake" products (ice-cream shake Rs.349, milk shake Rs.249) coexist
    assert menu["banana-shake"]["base_price"] == 349 and menu["banana-shake-milk-shakes"]["name"] == "Banana Shake"
    with S() as s:  # idempotent: a second run changes nothing, and never undoes the admin's edits
        s.query(models.Product).filter_by(slug="mango").update({"base_price": 170})
        s.commit()
        assert menu_seed.import_menu(s) == {"categories_added": 0, "products_added": 0, "demo_removed": 0}
        menu_seed.ensure_menu(s)
    assert _menu(c)["mango"]["base_price"] == 170 and len(_menu(c)) == 52


def test_admin_discount_applies_to_menu_and_checkout(client):
    from app import menu_seed
    c, S = client
    with S() as s:
        menu_seed.import_menu(s)
    h = _admin_headers(c, S)
    mango = _menu(c)["mango"]
    assert mango["discount_percent"] == 0 and [v["final_price"] for v in mango["variants"]] == [139, 219]
    assert c.patch(f"/api/admin/products/{mango['id']}", json={"discount_percent": 10}).status_code == 401
    assert c.patch(f"/api/admin/products/{mango['id']}", json={"discount_percent": 91}, headers=h).status_code == 422
    assert c.patch(f"/api/admin/products/{mango['id']}", json={"discount_percent": -1}, headers=h).status_code == 422
    r = c.patch(f"/api/admin/products/{mango['id']}", json={"discount_percent": 10}, headers=h)
    assert r.status_code == 200 and r.json()["discount_percent"] == 10 and r.json()["final_base_price"] == 125
    m = _menu(c)["mango"]
    assert m["discount_percent"] == 10 and [v["price"] for v in m["variants"]] == [139, 219]  # regular prices stay visible
    assert [v["final_price"] for v in m["variants"]] == [125, 197] and m["final_base_price"] == 125
    assert next(p for p in c.get("/api/admin/products", headers=h).json() if p["slug"] == "mango")["discount_percent"] == 10
    # the server charges the discounted price, whatever the client says
    q = c.post("/api/cart/quote", json={"items": [{"product_id": m["id"], "variant_id": m["variants"][1]["id"], "quantity": 2}], **at_km(2.5)}).json()
    assert q["lines"][0]["unit_price"] == 197 and q["lines"][0]["discount_percent"] == 10 and q["subtotal"] == 394 and q["total"] == 394 + 99
    # the base price is discounted too; other products are untouched
    cola = _menu(c)["pina-colada"]
    c.patch(f"/api/admin/products/{cola['id']}", json={"discount_percent": 25}, headers=h)
    assert _menu(c)["pina-colada"]["final_base_price"] == 209 and _menu(c)["oreo"]["discount_percent"] == 0
    q2 = c.post("/api/cart/quote", json={"items": [{"product_id": cola["id"], "variant_id": cola["variants"][0]["id"], "quantity": 1}], **at_km(2.5)}).json()
    assert q2["lines"][0]["unit_price"] == 209
    # removing the discount restores the regular price
    c.patch(f"/api/admin/products/{mango['id']}", json={"discount_percent": 0}, headers=h)
    assert [v["final_price"] for v in _menu(c)["mango"]["variants"]] == [139, 219]
    # the order snapshot keeps the price that was charged
    body = {**ORDER, "items": [{"product_id": cola["id"], "variant_id": cola["variants"][0]["id"], "quantity": 2}]}  # 2 x 209 (the shop's minimum order is Rs. 300)
    o = c.post("/api/orders", json=body, headers={"Idempotency-Key": "key-lllllllll"})
    assert o.status_code == 201 and o.json()["subtotal"] == 418


def test_startup_import_only_when_menu_missing(client):
    from app import menu_seed
    c, S = client
    with S() as s:
        menu_seed.ensure_menu(s)  # empty of real products -> imports
    assert len(_menu(c)) == 52
    h = _admin_headers(c, S)
    c.delete(f"/api/admin/products/{_menu(c)['oreo']['id']}", headers=h)
    with S() as s:
        menu_seed.ensure_menu(s)  # the menu is present -> a deleted product is not brought back
    assert "oreo" not in _menu(c) and len(_menu(c)) == 51


def _old_menu_in_db(S):
    """An already-deployed database: the previous menu (old prices, old slugs) and one product with a photo and a discount."""
    from app.menu_seed import _new_product  # noqa: F401  (same constructor the importer uses)
    with S() as s:
        cat = {c.slug: c for c in s.query(models.Category).all()}
        ice = models.Category(slug="ice-cream", name="Ice Cream", sort_order=0)
        soda = models.Category(slug="soda", name="Soda", sort_order=5)
        s.add_all([ice, soda]); s.flush()
        s.add_all([
            models.Product(slug="mango", name="Mango", category_id=ice.id, base_price=160, description="old", is_demo=False,
                           discount_percent=10, image_url="/media/products/mine.webp",
                           variants=[models.Variant(name="SINGLE", price=160, sort_order=0), models.Variant(name="DOUBLE", price=275, sort_order=1)]),
            models.Product(slug="lemon-soda", name="Lemon", category_id=soda.id, base_price=215, is_demo=False),  # not in the new menu
            models.Product(slug="my-own-special", name="Chef special", category_id=soda.id, base_price=500, is_demo=False),  # added by the admin
        ])
        s.commit()


def test_new_menu_file_only_adds_what_is_missing_on_an_existing_database(client):
    from app import menu_seed
    c, S = client
    _old_menu_in_db(S)
    with S() as s:
        menu_seed.ensure_menu(s)  # old menu present, new menu file never applied -> adds the missing products only
    menu = _menu(c)
    assert "lemon" in menu and len([k for k in menu if not k.startswith("demo")]) == 52 + 2  # file + lemon-soda + the admin's own
    assert "my-own-special" in menu and "lemon-soda" in menu  # nothing that exists is removed
    m = menu["mango"]  # the admin's version of an existing product is untouched
    assert m["base_price"] == 160 and m["description"] == "old" and [(v["name"], v["price"]) for v in m["variants"]] == [("SINGLE", 160), ("DOUBLE", 275)]
    assert m["discount_percent"] == 10 and m["image_url"] == "/media/products/mine.webp" and m["images"] == ["/media/products/mine.webp"]
    assert menu["loaded-waffle"]["base_price"] == 549 and [a["name"] for a in menu["loaded-waffle"]["addons"]] == ["With Ice Cream (4 Scoops)"]
    assert {x["slug"] for x in c.get("/api/menu").json()["categories"]} >= {"waffle", "faluda"}
    # it ran once: a later edit and a later restart are not undone
    with S() as s:
        s.query(models.Product).filter_by(slug="mango").update({"base_price": 150}); s.commit()
        menu_seed.ensure_menu(s)
    assert _menu(c)["mango"]["base_price"] == 150
    # a new version of the menu file again only adds; a product the admin changed stays changed
    with S() as s:
        s.query(models.AppMeta).delete(); s.commit()
        menu_seed.ensure_menu(s)
    assert _menu(c)["mango"]["base_price"] == 150
    # the explicit full sync (python -m app.menu_seed --sync) does overwrite and removes the old menu's leftovers
    with S() as s:
        menu_seed.sync_menu(s, overwrite=True)
    menu = _menu(c)
    assert menu["mango"]["base_price"] == 139 and "lemon-soda" not in menu and "my-own-special" in menu


def test_menu_file_real_photos_fill_slots_and_placeholders_are_ignored(client, monkeypatch):
    from app import menu_data, menu_seed
    c, S = client
    monkeypatch.setitem(menu_data.EXTRAS, "oreo", {**menu_data.EXTRAS["oreo"], "images": ["/media/products/a.webp", "/media/products/b.webp", "https://cdn.x/c.webp"]})
    with S() as s:
        menu_seed.import_menu(s)
    menu = _menu(c)
    assert menu["oreo"]["images"] == ["/media/products/a.webp", "/media/products/b.webp", "https://cdn.x/c.webp"]
    assert menu["oreo"]["image_url"] == "/media/products/a.webp"
    assert menu["mango"]["images"] == ["/media/products/8fca68ec6384628c2b95960fe1f3aa9d.webp"]  # the real photo address listed in the menu file
    assert menu_data._real_images({"image": "products/mango.jpg"}) == [] and menu_data._real_images({"images": ["/media/products/x.png"]}) == []


def test_product_can_have_several_photo_slots(client, monkeypatch, tmp_path):
    from app import menu_seed
    from app.config import settings as cfg
    monkeypatch.setattr(cfg, "upload_dir", str(tmp_path))
    c, S = client
    with S() as s:
        menu_seed.import_menu(s)
    h = _admin_headers(c, S)
    pid = _menu(c)["mango"]["id"]
    def up(path):  # one file to a slot
        return c.post(path, files={"file": ("x.webp", WEBP)}, headers=h)

    r1 = up(f"/api/admin/products/{pid}/image")  # slot 0 = main photo, as before
    assert r1.status_code == 200 and len(r1.json()["images"]) == 1 and r1.json()["image_url"] == r1.json()["images"][0]
    r2 = up(f"/api/admin/products/{pid}/image?slot=1")
    r3 = c.post(f"/api/admin/products/{pid}/images", files=[("files", ("a.webp", WEBP)), ("files", ("b.webp", WEBP))], headers=h)
    assert r2.status_code == 200 and r3.status_code == 200 and len(r3.json()["images"]) == 4
    m = _menu(c)["mango"]  # the public menu shows every photo, in slot order, and the main one first
    assert m["images"] == r3.json()["images"] and m["image_url"] == m["images"][0] and all(u.endswith(".webp") for u in m["images"])
    assert c.get("/api/products/mango").json()["images"] == m["images"]
    first, second = m["images"][0], m["images"][1]
    r4 = up(f"/api/admin/products/{pid}/image?slot=1")  # replacing a slot keeps the others
    assert r4.json()["images"][0] == first and r4.json()["images"][1] != second and len(r4.json()["images"]) == 4
    d = c.delete(f"/api/admin/products/{pid}/image?slot=0", headers=h)  # removing the main photo promotes the next one
    assert d.status_code == 200 and len(d.json()["images"]) == 3 and d.json()["image_url"] == d.json()["images"][0] != first
    assert c.delete(f"/api/admin/products/{pid}/image?slot=7", headers=h).status_code == 404
    assert next(p for p in c.get("/api/admin/products", headers=h).json() if p["slug"] == "mango")["images"] == d.json()["images"]
    # guards: admin only, WebP only (nothing is added if one file is bad), at most 8 photos
    assert c.post(f"/api/admin/products/{pid}/images", files=[("files", ("a.webp", WEBP))]).status_code == 401
    bad = c.post(f"/api/admin/products/{pid}/images", files=[("files", ("a.webp", WEBP)), ("files", ("b.png", PNG))], headers=h)
    assert bad.status_code == 422 and len(_menu(c)["mango"]["images"]) == 3
    too_many = c.post(f"/api/admin/products/{pid}/images", files=[("files", (f"{i}.webp", WEBP)) for i in range(6)], headers=h)
    assert too_many.status_code == 422 and len(_menu(c)["mango"]["images"]) == 3
    c.delete(f"/api/admin/products/{pid}", headers=h)  # deleting the product removes its photo slots with it
    with S() as s:
        assert s.query(models.ProductImage).filter_by(product_id=pid).count() == 0


def test_old_single_image_product_is_shown_and_can_get_more_slots(client, monkeypatch, tmp_path):
    from app import menu_seed
    from app.config import settings as cfg
    monkeypatch.setattr(cfg, "upload_dir", str(tmp_path))
    c, S = client
    with S() as s:
        menu_seed.import_menu(s)
        s.query(models.ProductImage).filter(models.ProductImage.product_id == s.query(models.Product.id).filter_by(slug="oreo").scalar_subquery()).delete(synchronize_session=False)
        s.query(models.Product).filter_by(slug="oreo").update({"image_url": "/media/products/old.webp"}); s.commit()
    h = _admin_headers(c, S)
    o = _menu(c)["oreo"]
    assert o["images"] == ["/media/products/old.webp"] and o["image_url"] == "/media/products/old.webp"  # a product from before the slots existed
    r = c.post(f"/api/admin/products/{o['id']}/image?slot=1", files={"file": ("n.webp", WEBP)}, headers=h)
    assert r.status_code == 200 and r.json()["images"][0] == "/media/products/old.webp" and len(r.json()["images"]) == 2


def test_admin_can_add_category_then_product_in_it(client):
    c, S = client
    h = _admin_headers(c, S)
    assert c.post("/api/admin/categories", json={"name": "Waffles"}).status_code in (401, 403)  # admin only
    r = c.post("/api/admin/categories", json={"name": "  Hot   Waffles "}, headers=h)
    assert r.status_code == 201 and r.json()["name"] == "Hot Waffles" and r.json()["slug"] == "hot-waffles" and r.json()["created"] is True
    cid = r.json()["id"]
    again = c.post("/api/admin/categories", json={"name": "hot waffles"}, headers=h).json()  # same name: no duplicate
    assert again["id"] == cid and again["created"] is False
    assert cid in [x["id"] for x in c.get("/api/admin/categories", headers=h).json()]
    before = len(c.get("/api/admin/products", headers=h).json())
    pid = c.post("/api/admin/products", json={"name": "Choco Waffle", "category_id": cid, "base_price": 350}, headers=h).json()["id"]
    assert len(c.get("/api/admin/products", headers=h).json()) == before + 1
    menu = {x["slug"]: x for x in c.get("/api/menu").json()["categories"]}
    assert [p["id"] for p in menu["hot-waffles"]["products"]] == [pid]


# ---- Frequently bought together
def test_bundle_default_admin_edit_and_cart(client):
    from app import menu_seed
    c, S = client
    with S() as s:
        menu_seed.import_menu(s)
        menu_seed.ensure_default_pairings(s)
    m = _menu(c)
    lw, vc = m["loaded-waffle"], m["vanilla-cream-waffle"]
    assert [b["name"] for b in lw["bundle"]] == ["Vanilla Cream Waffle"]  # seeded once
    b = lw["bundle"][0]
    assert b["id"] == vc["id"] and b["price"] == 249 and b["image_url"] == vc["image_url"] and b["variant_id"] is None
    assert vc["bundle"] == [] and c.get("/api/products/loaded-waffle").json()["bundle"][0]["id"] == vc["id"]
    h = _admin_headers(c, S)
    assert c.put(f"/api/admin/products/{lw['id']}/bundle", json={"product_ids": []}).status_code == 401  # admin only
    # the admin can put any product on any product, in the order sent; sizes use the first size's price
    mango, oreo = m["mango"], m["oreo"]
    r = c.put(f"/api/admin/products/{vc['id']}/bundle", json={"product_ids": [oreo["id"], mango["id"], oreo["id"]]}, headers=h)
    assert r.status_code == 200 and r.json()["product_ids"] == [oreo["id"], mango["id"]]  # duplicate dropped
    got = _menu(c)["vanilla-cream-waffle"]["bundle"]
    assert [x["name"] for x in got] == ["Oreo", "Mango"] and got[1]["variant_name"] == "SINGLE" and got[1]["price"] == 139 and got[1]["variant_id"]
    assert c.get(f"/api/admin/products/{vc['id']}/bundle", headers=h).json()["items"][0]["name"] == "Oreo"
    assert c.put(f"/api/admin/products/{vc['id']}/bundle", json={"product_ids": [vc["id"]]}, headers=h).status_code == 422  # not itself
    assert c.put(f"/api/admin/products/{vc['id']}/bundle", json={"product_ids": [999999]}, headers=h).status_code == 422
    # a suggested item that is switched off disappears from the shop, and the admin's removal of the default is not undone on restart
    c.patch(f"/api/admin/products/{oreo['id']}", json={"is_available": False}, headers=h)
    assert [x["name"] for x in _menu(c)["vanilla-cream-waffle"]["bundle"]] == ["Mango"]
    c.put(f"/api/admin/products/{lw['id']}/bundle", json={"product_ids": []}, headers=h)
    with S() as s:
        menu_seed.ensure_default_pairings(s)
    assert _menu(c)["loaded-waffle"]["bundle"] == []
    # the suggested item is an ordinary cart line: the server prices both lines
    q = c.post("/api/cart/quote", json={"items": [{"product_id": lw["id"], "quantity": 1}, {"product_id": vc["id"], "quantity": 1}], **at_km(1.0)}).json()
    assert q["subtotal"] == 549 + 249
    # deleting a product that is suggested elsewhere leaves no dangling suggestion
    c.put(f"/api/admin/products/{lw['id']}/bundle", json={"product_ids": [mango["id"]]}, headers=h)
    assert c.delete(f"/api/admin/products/{mango['id']}", headers=h).status_code == 200
    assert _menu(c)["loaded-waffle"]["bundle"] == []
