"""All money is whole PKR (int). Order items are snapshots."""
from datetime import datetime, timezone

from sqlalchemy import JSON, Boolean, DateTime, Float, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .config import settings as _cfg
from .db import Base


def now() -> datetime:
    return datetime.now(timezone.utc)


class Category(Base):
    __tablename__ = "categories"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80))
    slug: Mapped[str] = mapped_column(String(80), unique=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    products: Mapped[list["Product"]] = relationship(back_populates="category", order_by="Product.sort_order")

    def __str__(self) -> str:  # shown in the /admin site's lists and drop-downs
        return self.name


class Product(Base):
    __tablename__ = "products"
    id: Mapped[int] = mapped_column(primary_key=True)
    category_id: Mapped[int] = mapped_column(ForeignKey("categories.id"))
    name: Mapped[str] = mapped_column(String(120))
    slug: Mapped[str] = mapped_column(String(120), unique=True)
    description: Mapped[str | None] = mapped_column(Text)
    image_url: Mapped[str | None] = mapped_column(String(500))
    base_price: Mapped[int] = mapped_column(Integer)
    is_available: Mapped[bool] = mapped_column(Boolean, default=True)
    is_bestseller: Mapped[bool] = mapped_column(Boolean, default=False)
    is_featured: Mapped[bool] = mapped_column(Boolean, default=False)
    prep_minutes: Mapped[int | None] = mapped_column(Integer)
    discount_percent: Mapped[int] = mapped_column(Integer, default=0, server_default="0")  # set by the admin, 0-90 %
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False)
    category: Mapped[Category] = relationship(back_populates="products")
    variants: Mapped[list["Variant"]] = relationship(cascade="all, delete-orphan", order_by="Variant.sort_order")
    addons: Mapped[list["Addon"]] = relationship(cascade="all, delete-orphan", order_by="Addon.sort_order")
    # Photo slots: slot 1 is the main photo (image_url always mirrors it), the next slots are the extra photos.
    image_rows: Mapped[list["ProductImage"]] = relationship(cascade="all, delete-orphan", order_by="ProductImage.sort_order")
    # "Frequently bought together": other products the admin suggests next to this one (ordered).
    pairings: Mapped[list["ProductPairing"]] = relationship(
        foreign_keys="ProductPairing.product_id", cascade="all, delete-orphan", order_by="ProductPairing.sort_order", back_populates="product")
    paired_by: Mapped[list["ProductPairing"]] = relationship(  # rows on other products that point here: removed with this product
        foreign_keys="ProductPairing.paired_id", cascade="all, delete-orphan", back_populates="paired")
    __table_args__ = (Index("ix_products_cat", "category_id", "sort_order"),)

    @property
    def bundle(self) -> list[dict]:
        """What the customer sees under "Frequently bought together": available products only, each at its normal price
        (first available size if it has sizes, after the product's own discount)."""
        from .discounts import apply_discount
        out = []
        for r in self.pairings:
            q = r.paired
            if q is None or not q.is_available:
                continue
            v = next((x for x in q.variants if x.is_available), None)
            out.append({
                "id": q.id, "name": q.name, "slug": q.slug, "image_url": q.image_url,
                "variant_id": v.id if v else None, "variant_name": v.name if v else None,
                "price": apply_discount(v.price if v else q.base_price, q.discount_percent),
            })
        return out

    @property
    def images(self) -> list[str]:
        """Every photo of the product, in slot order. A product that only has the old single image_url still shows it."""
        urls = [r.url for r in self.image_rows]
        return urls or ([self.image_url] if self.image_url else [])

    def set_images(self, urls: list[str]) -> None:
        """Replace all photo slots with `urls` (in order) and keep image_url pointing at the first one."""
        self.image_rows = [ProductImage(url=u, sort_order=i) for i, u in enumerate(urls)]
        self.image_url = urls[0] if urls else None


class ProductPairing(Base):
    """"Frequently bought together": `paired` is suggested on `product`'s card and page. Set by the admin per product."""
    __tablename__ = "product_pairings"
    id: Mapped[int] = mapped_column(primary_key=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id", ondelete="CASCADE"), index=True)
    paired_id: Mapped[int] = mapped_column(ForeignKey("products.id", ondelete="CASCADE"), index=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    product: Mapped["Product"] = relationship(foreign_keys=[product_id], back_populates="pairings")
    paired: Mapped["Product"] = relationship(foreign_keys=[paired_id], back_populates="paired_by")
    __table_args__ = (UniqueConstraint("product_id", "paired_id", name="ux_pairing"),)


class ProductImage(Base):
    """One photo slot of a product (WebP, stored under /media/products). sort_order 0 is the main photo."""
    __tablename__ = "product_images"
    id: Mapped[int] = mapped_column(primary_key=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id", ondelete="CASCADE"), index=True)
    url: Mapped[str] = mapped_column(String(500))
    sort_order: Mapped[int] = mapped_column(Integer, default=0)


class AppMeta(Base):
    """Tiny key/value store for the app's own bookkeeping (e.g. which version of the menu file was last imported)."""
    __tablename__ = "app_meta"
    key: Mapped[str] = mapped_column(String(60), primary_key=True)
    value: Mapped[str] = mapped_column(String(200))


class Variant(Base):
    __tablename__ = "variants"
    id: Mapped[int] = mapped_column(primary_key=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(60))
    price: Mapped[int] = mapped_column(Integer)
    is_available: Mapped[bool] = mapped_column(Boolean, default=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)


class Addon(Base):
    __tablename__ = "addons"
    id: Mapped[int] = mapped_column(primary_key=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(60))
    price: Mapped[int] = mapped_column(Integer)
    is_available: Mapped[bool] = mapped_column(Boolean, default=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)


class Coupon(Base):
    __tablename__ = "coupons"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True)
    type: Mapped[str] = mapped_column(String(10))  # PERCENT | FIXED
    value: Mapped[int] = mapped_column(Integer)
    max_discount: Mapped[int | None] = mapped_column(Integer)
    min_subtotal: Mapped[int | None] = mapped_column(Integer)
    usage_limit: Mapped[int | None] = mapped_column(Integer)
    used_count: Mapped[int] = mapped_column(Integer, default=0)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class BusinessSettings(Base):
    """Single row (id=1). Editable from the admin dashboard in a later phase."""
    __tablename__ = "business_settings"
    id: Mapped[int] = mapped_column(primary_key=True, default=1)
    business_name: Mapped[str] = mapped_column(String(80), default="Cravy")
    phone: Mapped[str | None] = mapped_column(String(30))
    announcement: Mapped[str | None] = mapped_column(String(200))
    delivery_charge: Mapped[int] = mapped_column(Integer, default=0)
    min_order_value: Mapped[int] = mapped_column(Integer, default=0)
    tax_percent: Mapped[int] = mapped_column(Integer, default=0)  # added on top of (subtotal - discount)
    cod_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    easypaisa_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    easypaisa_name: Mapped[str | None] = mapped_column(String(80), default=lambda: _cfg.easypaisa_account_name)
    easypaisa_number: Mapped[str | None] = mapped_column(String(30), default=lambda: _cfg.easypaisa_number)
    bank_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    bank_name: Mapped[str | None] = mapped_column(String(80))
    bank_account_title: Mapped[str | None] = mapped_column(String(80))
    bank_account_number: Mapped[str | None] = mapped_column(String(40))
    bank_iban: Mapped[str | None] = mapped_column(String(40))
    shop_latitude: Mapped[float | None] = mapped_column(Float)  # where delivery distance is measured from
    shop_longitude: Mapped[float | None] = mapped_column(Float)


class Order(Base):
    __tablename__ = "orders"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_number: Mapped[str] = mapped_column(String(30), unique=True)
    idempotency_key: Mapped[str] = mapped_column(String(80), unique=True)
    status: Mapped[str] = mapped_column(String(30), default="PENDING", index=True)  # PENDING | COMPLETED | CANCELLED
    customer_name: Mapped[str] = mapped_column(String(120))
    customer_phone: Mapped[str] = mapped_column(String(30), index=True)
    customer_email: Mapped[str | None] = mapped_column(String(160))
    city: Mapped[str] = mapped_column(String(80))
    address: Mapped[str] = mapped_column(String(300))
    landmark: Mapped[str | None] = mapped_column(String(160))
    instructions: Mapped[str | None] = mapped_column(String(300))
    subtotal: Mapped[int] = mapped_column(Integer)
    delivery_charge: Mapped[int] = mapped_column(Integer, default=0)
    discount_total: Mapped[int] = mapped_column(Integer, default=0)
    tax_total: Mapped[int] = mapped_column(Integer, default=0)
    delivery_zone: Mapped[str | None] = mapped_column(String(80))  # snapshot of the distance band, e.g. "2-3 km"
    delivery_distance_km: Mapped[float | None] = mapped_column(Float)
    latitude: Mapped[float | None] = mapped_column(Float)  # customer's map pin
    longitude: Mapped[float | None] = mapped_column(Float)
    total: Mapped[int] = mapped_column(Integer)
    coupon_code: Mapped[str | None] = mapped_column(String(40))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, index=True)
    updated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=now)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    items: Mapped[list["OrderItem"]] = relationship(back_populates="order", cascade="all, delete-orphan")
    payment: Mapped["Payment"] = relationship(back_populates="order", uselist=False, cascade="all, delete-orphan")


class OrderItem(Base):
    __tablename__ = "order_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id", ondelete="CASCADE"), index=True)
    product_id: Mapped[int | None] = mapped_column(Integer)
    product_name: Mapped[str] = mapped_column(String(120))
    variant_name: Mapped[str | None] = mapped_column(String(60))
    addons: Mapped[list] = mapped_column(JSON, default=list)
    unit_price: Mapped[int] = mapped_column(Integer)
    quantity: Mapped[int] = mapped_column(Integer)
    line_total: Mapped[int] = mapped_column(Integer)
    order: Mapped[Order] = relationship(back_populates="items")


class Payment(Base):
    __tablename__ = "payments"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id", ondelete="CASCADE"), unique=True)
    method: Mapped[str] = mapped_column(String(20))  # COD | EASYPAISA
    # COD: UNPAID -> PAID (cash collected).  EASYPAISA: AWAITING_PAYMENT -> PENDING_VERIFICATION -> PAID (or FAILED)
    status: Mapped[str] = mapped_column(String(25), default="UNPAID")
    amount: Mapped[int] = mapped_column(Integer)
    transaction_ref: Mapped[str | None] = mapped_column(String(120), unique=True)  # one Easypaisa TID can pay only one order
    receipt_path: Mapped[str | None] = mapped_column(String(300))
    admin_note: Mapped[str | None] = mapped_column(String(300))
    order: Mapped[Order] = relationship(back_populates="payment")
    __table_args__ = (Index("ix_payment_status", "status", "method"),)


class AdminUser(Base):
    __tablename__ = "admin_users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(160), unique=True)
    password_hash: Mapped[str] = mapped_column(String(300))
    role: Mapped[str] = mapped_column(String(10), default="OWNER")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class NotificationLog(Base):
    """A row means we attempted a send. status SENT is set only when the SMTP server accepted the message."""
    __tablename__ = "notification_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int | None] = mapped_column(ForeignKey("orders.id", ondelete="SET NULL"), index=True)
    channel: Mapped[str] = mapped_column(String(12))
    recipient: Mapped[str] = mapped_column(String(160))
    template: Mapped[str] = mapped_column(String(40))
    status: Mapped[str] = mapped_column(String(10), default="QUEUED")
    error: Mapped[str | None] = mapped_column(String(300))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))